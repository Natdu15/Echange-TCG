// animeManager.js
class AnimeManager {
  constructor(soundManager) {
    this.soundManager = soundManager;
  }

  hoverIn(el){
    this.soundManager.play('clic');
    anime.remove(el);
    anime({
      targets: el,
      scale: 1.15,
      rotateZ: anime.random(-5,5),
      translateY:-12,
      duration:300,
      easing:'easeOutBack',
      filter: 'drop-shadow(0px 0px 20px #7c3aed)'
    });
  }

  hoverOut(el){
    anime.remove(el);
    anime({
      targets: el,
      scale: 1,
      rotateZ:0,
      translateY:0,
      duration:250,
      easing:'easeOutQuad',
      filter:'drop-shadow(0px 0px 0px transparent)'
    });
  }

  flip(el,on=true){
    this.soundManager.play('flip');
    const inner = el.querySelector('.card-inner');
    if(!inner) return;
    anime.remove(inner);
    anime({
      targets: inner,
      rotateY:on?180:0,
      scale:[1,1.05,1],
      duration:600,
      easing:'cubicBezier(.2,.8,.2,1)',
      boxShadow:['0 8px 20px rgba(0,0,0,0.6)','0 20px 40px rgba(124,58,237,0.7)']
    });
  }

  shuffle(cards){
    this.soundManager.play('shuffle');
    anime.remove(cards);
    anime({
      targets: cards,
      translateX:()=>anime.random(-80,80),
      translateY:()=>anime.random(-40,40),
      rotate:()=>anime.random(-30,30),
      scale:[1,1.08,1],
      duration:800,
      easing:'easeInOutSine',
      delay:anime.stagger(50)
    });
  }

  deal(deckEl,cards,positions){
    this.soundManager.play('deal');
    const deckRect = deckEl.getBoundingClientRect();
    cards.forEach((card,i)=>{
      const target = positions[i];
      const dx = target.x - deckRect.left;
      const dy = target.y - deckRect.top;
      anime({
        targets:card,
        translateX:dx,
        translateY:dy,
        rotate:anime.random(-15,15),
        scale:[0.8,1.1,1],
        duration:700,
        easing:'easeInOutCubic',
        delay:i*80
      });
    });
  }

  victory(el){
    this.soundManager.play('victory');
    anime({
      targets:el,
      scale:[0.7,1.2,1],
      rotate:[-10,10,0],
      opacity:[0,1],
      duration:1000,
      easing:'spring(1,80,10,0)'
    });

    for(let i=0;i<30;i++){
      const c=document.createElement('div');
      c.style.position='fixed';
      c.style.left=window.innerWidth/2+'px';
      c.style.top=window.innerHeight/2+'px';
      c.style.width=c.style.height=anime.random(6,16)+'px';
      c.style.background=`hsl(${anime.random(0,360)},80%,60%)`;
      c.style.borderRadius='50%';
      document.body.appendChild(c);
      anime({
        targets:c,
        translateX:anime.random(-400,400),
        translateY:anime.random(-300,-600),
        rotate:anime.random(-720,720),
        opacity:[1,0],
        duration:anime.random(900,1500),
        easing:'easeInQuad',
        complete:()=>c.remove()
      });
    }
  }

  entranceStagger(targets){
    anime.remove(targets);
    anime({
      targets,
      translateY:[30,0],
      opacity:[0,1],
      duration:600,
      easing:'easeOutQuad',
      delay:anime.stagger(80)
    });
  }
}
