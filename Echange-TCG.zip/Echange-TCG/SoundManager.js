// SoundManager.js
class SoundManager {
  constructor() {
    this.sons = {
      son1: new Howl({ src: ['son-tcgp/fave.mp3'], preload: true, volume: 1 }),
      son2: new Howl({ src: ['son-tcgp/fete.mp3'], preload: true, volume: 1 }),
      son3: new Howl({ src: ['son-tcgp/fortnite.mp3'], preload: true, volume: 1 }),
      son4: new Howl({ src: ['son-tcgp/kaydop.mp3'], preload: true, volume: 1 }),
      son5: new Howl({ src: ['son-tcgp/pet.mp3'], preload: true, volume: 1 })
    };

    // Préchargement manuel pour garantir zéro latence
    Object.values(this.sons).forEach(son => son.load());
  }

  play(nom) {
    const son = this.sons[nom];
    if (son) son.play();
  }
}
