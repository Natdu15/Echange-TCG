# Echange-TCG
Site qui reprend les bases du jeu Pokémon TCGP.
